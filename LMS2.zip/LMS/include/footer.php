<script src="<?php echo BASE_URL ?>assets/js/jquery-3.7.1.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/dataTables.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/dataTables.bootstrap5.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/bootstrap.bundle.min.js"></script>

<!-- <script>
    new DataTable('#example');
</script> -->
<script>
    $(document).ready(function() {
        $('#data-table').DataTable();
    });
</script>
</body>

</html>